#!/bin/bash

# Chemin du dossier à archiver
DOSSIER="$1"

# Nom du zip à générer (le nom du dossier avec extension .zip)
NOM_ZIP="$(basename "$DOSSIER").zip"

# Supprimer le zip existant s'il existe
if [ -f "$DOSSIER/$NOM_ZIP" ]; then
    echo "Suppression de l'ancien fichier $NOM_ZIP..."
    rm "$DOSSIER/$NOM_ZIP"
fi

# Créer une nouvelle archive zip à partir du contenu du dossier
echo "Création du nouveau fichier $NOM_ZIP..."
(cd "$DOSSIER" && zip -r "$NOM_ZIP" . -x "$NOM_ZIP")

echo "Opération terminée : $DOSSIER/$NOM_ZIP"

